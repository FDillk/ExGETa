var hybrid__classifier_8h =
[
    [ "HybridClassifier", "hybrid__classifier_8h.html#a2316c4d5984f224ca2a396e80ad94117", null ],
    [ "hybrid_classifier_classify", "hybrid__classifier_8h.html#a4bbd0fb1240bcb7ff4d9d14771181987", null ],
    [ "hybrid_classifier_create", "hybrid__classifier_8h.html#a59f426db75c7edf19801468bc7fae504", null ],
    [ "hybrid_classifier_delete", "hybrid__classifier_8h.html#afa833f73ec00f93a32a619966a8cbb47", null ],
    [ "hybrid_classifier_score", "hybrid__classifier_8h.html#a1bb102878e52721aad5b00ed061b86a6", null ]
];