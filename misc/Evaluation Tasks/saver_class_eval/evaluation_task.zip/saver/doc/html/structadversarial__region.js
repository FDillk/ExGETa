var structadversarial__region =
[
    [ "perturbation", "structadversarial__region.html#a373cb950405fc0c778f66d9b742fd402", null ],
    [ "sample", "structadversarial__region.html#a15b39e2593666005d00557935139ad26", null ]
];