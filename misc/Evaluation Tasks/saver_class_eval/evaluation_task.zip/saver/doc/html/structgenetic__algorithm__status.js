var structgenetic__algorithm__status =
[
    [ "buffer", "structgenetic__algorithm__status.html#aea36590ce7db50de6140783f589b6c19", null ],
    [ "data", "structgenetic__algorithm__status.html#a7da862c04a789949ba6a77dbdb686f02", null ],
    [ "elitism", "structgenetic__algorithm__status.html#a47e59c6bb857b5db49e0e02398867e4e", null ],
    [ "fitness", "structgenetic__algorithm__status.html#abed7b238d88acd8343f863ae565ad04b", null ],
    [ "fitness_mean", "structgenetic__algorithm__status.html#a8f169150d096f6246d23f8399954079d", null ],
    [ "fitness_variance", "structgenetic__algorithm__status.html#a4f3b46053a0d3d3be9829cbaf589f6bf", null ],
    [ "generation", "structgenetic__algorithm__status.html#ac24b1ebdfb0811c792db5a58fe56522c", null ],
    [ "genes", "structgenetic__algorithm__status.html#a037e339f6ece4af89580b7307b4c6d60", null ],
    [ "individual_size", "structgenetic__algorithm__status.html#a9258f79a18d373b2f85f038ef4ddfa94", null ],
    [ "max_generation", "structgenetic__algorithm__status.html#a23713ff7857dc9632ccb31aa1eb632bc", null ],
    [ "max_population_size", "structgenetic__algorithm__status.html#a47abd27ed78348b1ad9b82f10437b4e2", null ],
    [ "normalized_fitness", "structgenetic__algorithm__status.html#a06ffa602e3143e9306c2a1880f9bab9d", null ],
    [ "population", "structgenetic__algorithm__status.html#abb28e1f3c344805f2db665516e328f62", null ],
    [ "population_size", "structgenetic__algorithm__status.html#a39f5a6c3d200f4dc9f6bce0375db4a25", null ]
];