var searchData=
[
  ['y_0',['y',['../structpoint2d.html#a62ced03d3bb8c2add8c0a35c97ec2469',1,'point2d']]]
];
