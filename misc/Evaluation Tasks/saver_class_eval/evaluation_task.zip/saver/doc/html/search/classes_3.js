var searchData=
[
  ['genetic_5falgorithm_5fstatus_0',['genetic_algorithm_status',['../structgenetic__algorithm__status.html',1,'']]]
];
