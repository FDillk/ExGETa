var searchData=
[
  ['max_0',['max',['../type_8h.html#ac39d9cef6a5e030ba8d9e11121054268',1,'type.h']]],
  ['min_1',['min',['../type_8h.html#abb702d8b501669a23aa0ab3b281b9384',1,'type.h']]]
];
