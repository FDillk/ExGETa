var searchData=
[
  ['n_5fclasses_0',['n_classes',['../structclassifier.html#a8006c1f000c2d5d13b466131e38ec9c2',1,'classifier']]],
  ['n_5fsupport_5fvectors_1',['n_support_vectors',['../structclassifier.html#aeeb189301bca60d23f36eaed638017bc',1,'classifier']]],
  ['noise_2',['noise',['../structraf.html#a7e4273a14d25d3fa4e28f5c27bd511b8',1,'raf']]],
  ['normalized_5ffitness_3',['normalized_fitness',['../structgenetic__algorithm__status.html#a06ffa602e3143e9306c2a1880f9bab9d',1,'genetic_algorithm_status']]]
];
