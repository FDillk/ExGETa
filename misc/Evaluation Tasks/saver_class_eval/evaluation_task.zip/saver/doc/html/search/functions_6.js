var searchData=
[
  ['kernel_5fcompute_0',['kernel_compute',['../kernel_8h.html#aa889c42bf0e25cfe7eed1d8c7b63237d',1,'kernel.c']]],
  ['kernel_5fcreate_1',['kernel_create',['../kernel_8h.html#ad0718e5f568ea4277631d0639fc3b77a',1,'kernel.c']]],
  ['kernel_5fdelete_2',['kernel_delete',['../kernel_8h.html#a4d4fe2dd6f4147f8f05684df8af3ba0d',1,'kernel.c']]],
  ['kernel_5fget_5fc_3',['kernel_get_c',['../kernel_8h.html#a42a6a5a0a5e77a442729617b89d0704e',1,'kernel.c']]],
  ['kernel_5fget_5fdegree_4',['kernel_get_degree',['../kernel_8h.html#aa48df96ab78b79f72de51ce5118a65c8',1,'kernel.c']]],
  ['kernel_5fget_5fgamma_5',['kernel_get_gamma',['../kernel_8h.html#a62a748f20705d55afdb3284183120f27',1,'kernel.c']]],
  ['kernel_5fget_5ftype_6',['kernel_get_type',['../kernel_8h.html#ad3a13d57e3fd7e06f7dd0ff766c95758',1,'kernel.c']]]
];
