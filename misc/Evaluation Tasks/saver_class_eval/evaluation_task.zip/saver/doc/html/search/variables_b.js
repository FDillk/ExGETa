var searchData=
[
  ['magnitude_0',['magnitude',['../structperturbation.html#a92d48c2b87444184b0a208b9dfac4a1b',1,'perturbation']]],
  ['max_5fgeneration_1',['max_generation',['../structgenetic__algorithm__status.html#a23713ff7857dc9632ccb31aa1eb632bc',1,'genetic_algorithm_status']]],
  ['max_5fpopulation_5fsize_2',['max_population_size',['../structgenetic__algorithm__status.html#a47abd27ed78348b1ad9b82f10437b4e2',1,'genetic_algorithm_status']]]
];
