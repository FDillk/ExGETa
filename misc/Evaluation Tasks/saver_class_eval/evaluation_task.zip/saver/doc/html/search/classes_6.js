var searchData=
[
  ['kernel_0',['kernel',['../structkernel.html',1,'']]]
];
