var searchData=
[
  ['bias_0',['bias',['../structclassifier.html#a290405cf7f4aa73c9ebf30de21ab9b13',1,'classifier']]],
  ['buffer_1',['buffer',['../structhybrid__classifier.html#a60bb34a0b49801f43ae96dee633e8777',1,'hybrid_classifier::buffer()'],['../structinterval__classifier.html#add85af0cf00060d8791946a91e4e9925',1,'interval_classifier::buffer()'],['../structraf__classifier.html#a5e3c514d0143d8070ec0e006acf25fd9',1,'raf_classifier::buffer()'],['../structclassifier.html#a3a62fada438b9a5c18e56580666edaa5',1,'classifier::buffer()'],['../structgenetic__algorithm__status.html#aea36590ce7db50de6140783f589b6c19',1,'genetic_algorithm_status::buffer()']]]
];
