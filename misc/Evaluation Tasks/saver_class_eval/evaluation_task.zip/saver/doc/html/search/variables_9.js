var searchData=
[
  ['kernel_0',['kernel',['../structclassifier.html#a98500ed270d46895178582284ae5da1e',1,'classifier']]]
];
