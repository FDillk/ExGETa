var searchData=
[
  ['dataset_5fdelete_0',['dataset_delete',['../dataset_8h.html#a943310cbb203c3701e98d33882b663b3',1,'dataset.c']]],
  ['dataset_5fget_5flabel_1',['dataset_get_label',['../dataset_8h.html#a780f8caa40b462b5a79bab4427800111',1,'dataset.c']]],
  ['dataset_5fget_5frow_2',['dataset_get_row',['../dataset_8h.html#a646ec8767b1db3886048aadfd0312a1c',1,'dataset.c']]],
  ['dataset_5fget_5fsize_3',['dataset_get_size',['../dataset_8h.html#a8a845d6de556d93595f331873222a38f',1,'dataset.c']]],
  ['dataset_5fget_5fspace_5fsize_4',['dataset_get_space_size',['../dataset_8h.html#abc0ed2cf447d82c931938e5e2f1d0899',1,'dataset.c']]],
  ['dataset_5fread_5',['dataset_read',['../dataset_8h.html#a583f1c86ab8f1ae93ecc2b4763db6e14',1,'dataset.c']]],
  ['display_5fhelp_6',['display_help',['../saver_8c.html#a5d2804d46b7f0a9d38971261a0b46b7a',1,'saver.c']]]
];
