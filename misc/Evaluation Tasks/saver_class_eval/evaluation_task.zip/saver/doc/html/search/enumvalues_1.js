var searchData=
[
  ['kernel_5flinear_0',['KERNEL_LINEAR',['../kernel_8h.html#a20fb43c4dec0741b9e11a076701f19e9a0013f4c8698c727a0387d9bb43331e2c',1,'kernel.h']]],
  ['kernel_5fpolynomial_1',['KERNEL_POLYNOMIAL',['../kernel_8h.html#a20fb43c4dec0741b9e11a076701f19e9ae2095b04c2c93d7a0b4359f10f7527d0',1,'kernel.h']]],
  ['kernel_5frbf_2',['KERNEL_RBF',['../kernel_8h.html#a20fb43c4dec0741b9e11a076701f19e9aca9296ec7d7cd06b0395a5fe612aa7cb',1,'kernel.h']]]
];
