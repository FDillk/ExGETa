var searchData=
[
  ['default_5fabstraction_0',['DEFAULT_ABSTRACTION',['../abstract__classifier_8h.html#a68e0e8e420bed0babf95cb447f7d02da',1,'abstract_classifier.h']]],
  ['default_5fepsilon_1',['DEFAULT_EPSILON',['../perturbation_8h.html#a7da9461adfc6cbaa9daa6fd8b061650d',1,'perturbation.h']]],
  ['default_5fperturbation_2',['DEFAULT_PERTURBATION',['../perturbation_8h.html#a8572b923aaff2d05ecaa9a7ca6e04429',1,'perturbation.h']]]
];
