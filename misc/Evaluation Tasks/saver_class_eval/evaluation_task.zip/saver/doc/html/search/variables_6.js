var searchData=
[
  ['gamma_0',['gamma',['../structkernel.html#a1e8bc3109fcd6cdd247e332091eac01a',1,'kernel']]],
  ['generation_1',['generation',['../structgenetic__algorithm__status.html#ac24b1ebdfb0811c792db5a58fe56522c',1,'genetic_algorithm_status']]],
  ['genes_2',['genes',['../structgenetic__algorithm__status.html#a037e339f6ece4af89580b7307b4c6d60',1,'genetic_algorithm_status']]]
];
