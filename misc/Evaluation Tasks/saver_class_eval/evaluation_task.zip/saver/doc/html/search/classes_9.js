var searchData=
[
  ['raf_0',['raf',['../structraf.html',1,'']]],
  ['raf_5fclassifier_1',['raf_classifier',['../structraf__classifier.html',1,'']]]
];
