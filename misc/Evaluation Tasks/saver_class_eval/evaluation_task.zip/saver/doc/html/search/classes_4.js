var searchData=
[
  ['hybrid_5fclassifier_0',['hybrid_classifier',['../structhybrid__classifier.html',1,'']]]
];
