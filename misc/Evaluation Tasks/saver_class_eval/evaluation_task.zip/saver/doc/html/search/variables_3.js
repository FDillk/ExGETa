var searchData=
[
  ['data_0',['data',['../structdataset.html#a2156f8d0c04417f209f43827f89d6015',1,'dataset::data()'],['../structgenetic__algorithm__status.html#a7da862c04a789949ba6a77dbdb686f02',1,'genetic_algorithm_status::data()']]],
  ['debug_5foutput_1',['debug_output',['../structoptions.html#a56174b499a001879c73add4f9f0f60f4',1,'options']]],
  ['degree_2',['degree',['../structkernel.html#af590d295ae525e63a9411104f83ca96f',1,'kernel']]],
  ['delta_3',['delta',['../structraf.html#af2679ccfbd4b68d4f1f651fdc2b3cc1c',1,'raf']]]
];
