var searchData=
[
  ['report_5ferror_0',['report_error',['../report__error_8h.html#af122b7b57c8a2e4c18f74f834bda9ff5',1,'report_error.h']]],
  ['report_5fwarning_1',['report_warning',['../report__error_8h.html#abf0c3d3cf7b9ace1cbbc38a4a3de6915',1,'report_error.h']]],
  ['round_5fdown_2',['round_down',['../type_8h.html#aec51294914151e64536e79a46ec1e9c8',1,'type.h']]],
  ['round_5fup_3',['round_up',['../type_8h.html#a3ee29932c4652551fba3131bdc706f95',1,'type.h']]]
];
