var searchData=
[
  ['stopwatch_5fcreate_0',['stopwatch_create',['../stopwatch_8h.html#ab1380b9989d874c4634e3efd2301a809',1,'stopwatch.c']]],
  ['stopwatch_5fdelete_1',['stopwatch_delete',['../stopwatch_8h.html#adc86c835c55f0368048d19df250ecfec',1,'stopwatch.c']]],
  ['stopwatch_5fget_5felapsed_5fmilliseconds_2',['stopwatch_get_elapsed_milliseconds',['../stopwatch_8h.html#ad21778e2721282d5c00bf34a4faf3fbc',1,'stopwatch.c']]],
  ['stopwatch_5fstart_3',['stopwatch_start',['../stopwatch_8h.html#a644c108bcb93d0024731b79f516caf6b',1,'stopwatch.c']]],
  ['stopwatch_5fstop_4',['stopwatch_stop',['../stopwatch_8h.html#a2becb656065a8dd7f407b2e07f56c79b',1,'stopwatch.c']]]
];
