var searchData=
[
  ['kerneltype_0',['KernelType',['../kernel_8h.html#a20fb43c4dec0741b9e11a076701f19e9',1,'kernel.h']]]
];
