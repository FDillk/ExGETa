var searchData=
[
  ['raf_0',['Raf',['../raf_8h.html#af9089de95c2e4815471c42a584183dca',1,'raf.h']]],
  ['rafclassifier_1',['RafClassifier',['../raf__classifier_8h.html#a7b35695c4c0126e97c062b1fc141578c',1,'raf_classifier.h']]],
  ['real_2',['Real',['../type_8h.html#ab685845059e8a2c92743427d9a698c70',1,'type.h']]]
];
