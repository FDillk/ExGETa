var searchData=
[
  ['sample_0',['sample',['../structadversarial__region.html#a15b39e2593666005d00557935139ad26',1,'adversarial_region']]],
  ['samples_1',['samples',['../structcounterexample.html#ab23f44ef1d30941e55bbb92850b64025',1,'counterexample']]],
  ['samples_5fnumber_2',['samples_number',['../structcounterexample.html#aa4ac8a180d138f7af1b0b9a6cee8a38a',1,'counterexample']]],
  ['size_3',['size',['../structraf.html#ae4b42bd8cafc31d2ef251b85f4daed95',1,'raf::size()'],['../structdataset.html#ad329e7d991db8f41f104a366eea89f3f',1,'dataset::size()']]],
  ['space_5fsize_4',['space_size',['../structclassifier.html#aa300f8981dc952371f538e5a3e092a11',1,'classifier::space_size()'],['../structcounterexample.html#ab6ca212dd5e2222810acadf0697b430c',1,'counterexample::space_size()'],['../structdataset.html#aacf9924c0d4cbf22703daed5896f4987',1,'dataset::space_size()'],['../structperturbation.html#a67c69469292aa9662a4806e45cef08d4',1,'perturbation::space_size()']]],
  ['start_5ftime_5',['start_time',['../structstopwatch.html#a7a344c59b79cee7ab76a8d66713bfbc9',1,'stopwatch']]],
  ['stop_5ftime_6',['stop_time',['../structstopwatch.html#a98db6c786c32091663c2495279e357d3',1,'stopwatch']]],
  ['support_5fvectors_7',['support_vectors',['../structclassifier.html#a963799a24fea436ee850268049802c00',1,'classifier']]]
];
