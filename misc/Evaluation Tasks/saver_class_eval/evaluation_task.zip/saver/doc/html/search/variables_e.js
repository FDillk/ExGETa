var searchData=
[
  ['raf_5fclassifier_0',['raf_classifier',['../structhybrid__classifier.html#a206bca27a33e66264fcc3f7dd6fd6bfb',1,'hybrid_classifier']]]
];
