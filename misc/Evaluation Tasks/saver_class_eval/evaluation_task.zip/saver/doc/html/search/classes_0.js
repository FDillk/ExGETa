var searchData=
[
  ['abstract_5fclassifier_0',['abstract_classifier',['../structabstract__classifier.html',1,'']]],
  ['adversarial_5fregion_1',['adversarial_region',['../structadversarial__region.html',1,'']]]
];
