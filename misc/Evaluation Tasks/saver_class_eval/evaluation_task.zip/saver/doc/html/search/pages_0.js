var searchData=
[
  ['mainpage_20placeholder_0',['Mainpage placeholder',['../index.html',1,'']]]
];
