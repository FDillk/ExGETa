var structhybrid__classifier =
[
    [ "buffer", "structhybrid__classifier.html#a60bb34a0b49801f43ae96dee633e8777", null ],
    [ "classifier", "structhybrid__classifier.html#ab253cc6e00d2a17b22a3e08f8667d78d", null ],
    [ "interval_classifier", "structhybrid__classifier.html#a64c7e3e17c6a961e56eccab3097b2651", null ],
    [ "raf_classifier", "structhybrid__classifier.html#a206bca27a33e66264fcc3f7dd6fd6bfb", null ]
];