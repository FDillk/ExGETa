var structcounterexample =
[
    [ "samples", "structcounterexample.html#ab23f44ef1d30941e55bbb92850b64025", null ],
    [ "samples_number", "structcounterexample.html#aa4ac8a180d138f7af1b0b9a6cee8a38a", null ],
    [ "space_size", "structcounterexample.html#ab6ca212dd5e2222810acadf0697b430c", null ]
];