var abstract__classifier_8h =
[
    [ "DEFAULT_ABSTRACTION", "abstract__classifier_8h.html#a68e0e8e420bed0babf95cb447f7d02da", null ],
    [ "AbstractClassifier", "abstract__classifier_8h.html#aadd8b82e63a1ff95187c32b4763eeba3", null ],
    [ "abstract_classifier_classify", "abstract__classifier_8h.html#a9d31dd57bb08f7b8c6cfd10928ba07f9", null ],
    [ "abstract_classifier_create", "abstract__classifier_8h.html#a62321a99327c13866c9063f61888be75", null ],
    [ "abstract_classifier_delete", "abstract__classifier_8h.html#a73bc7248661b6376321b09a58a2a011c", null ],
    [ "abstract_classifier_get_classifier", "abstract__classifier_8h.html#a70b15c83f66f5692b3686ac872b194a0", null ],
    [ "abstract_classifier_read", "abstract__classifier_8h.html#a77f845677098b96f2dabd28ec7478cd5", null ],
    [ "abstract_classifier_score", "abstract__classifier_8h.html#a08de4dd0d6cd9d98e8fa8b21604704ea", null ]
];