var structperturbation =
[
    [ "clipped_hyperrectangle", "structperturbation.html#a78fa4bd37a36f252a2f561ff84db2de1", null ],
    [ "epsilon_l", "structperturbation.html#abf38815762ea90c5296e7eb9fd578602", null ],
    [ "epsilon_u", "structperturbation.html#a103035184bb606891b6d3190d239cfe9", null ],
    [ "fh", "structperturbation.html#a17053cb20086edaba82d16588c253f59", null ],
    [ "frame", "structperturbation.html#a6a2f92fce1f0257f300d525068b3545b", null ],
    [ "frame_height", "structperturbation.html#ad024231beb269cd6ed591a5f396572fc", null ],
    [ "frame_width", "structperturbation.html#af898ad8312ca2f87085a4efd8043b4ad", null ],
    [ "hyper_rectangle", "structperturbation.html#a5f9fa3bac749cc1d3f3eb4d34bd7db9b", null ],
    [ "image_height", "structperturbation.html#a0532e1ab9343480cd3ad27507b7e5ffb", null ],
    [ "image_width", "structperturbation.html#accfc5c0f2a863ee9f36da05ab7919af8", null ],
    [ "l", "structperturbation.html#a1acfe5b229a9faf11d4aa7635e232649", null ],
    [ "magnitude", "structperturbation.html#a92d48c2b87444184b0a208b9dfac4a1b", null ],
    [ "perturbation_data", "structperturbation.html#a966c0b17599f763ef827f55869af732c", null ],
    [ "space_size", "structperturbation.html#a67c69469292aa9662a4806e45cef08d4", null ],
    [ "type", "structperturbation.html#a465f9eb9ce674d296ecde11be9d52852", null ],
    [ "u", "structperturbation.html#a3bafd65a084e1116bbd385520fed6965", null ]
];