var perturbation_8h =
[
    [ "DEFAULT_EPSILON", "perturbation_8h.html#a7da9461adfc6cbaa9daa6fd8b061650d", null ],
    [ "DEFAULT_PERTURBATION", "perturbation_8h.html#a8572b923aaff2d05ecaa9a7ca6e04429", null ],
    [ "Perturbation", "perturbation_8h.html#ab1b58ce71af0704c3f658393ad45253c", null ],
    [ "PerturbationType", "perturbation_8h.html#a335364b39450e23bfefded6b7af8908c", [
      [ "PERTURBATION_L_ONE", "perturbation_8h.html#a335364b39450e23bfefded6b7af8908ca470940848eb97f22ce943cbb18a13909", null ],
      [ "PERTURBATION_L_INF", "perturbation_8h.html#a335364b39450e23bfefded6b7af8908ca257be62e2746a210a3193bc3447cf040", null ],
      [ "PERTURBATION_HYPER_RECTANGLE", "perturbation_8h.html#a335364b39450e23bfefded6b7af8908ca6b63287b8c633187fdb66df53d015cec", null ],
      [ "PERTURBATION_FRAME", "perturbation_8h.html#a335364b39450e23bfefded6b7af8908ca9e807c87a04ed0aa360a0879b7961792", null ],
      [ "PERTURBATION_CLIPPED_HYPERRECTANGLE", "perturbation_8h.html#a335364b39450e23bfefded6b7af8908cab206d2c0158137ca6570b89518a6035a", null ],
      [ "PERTURBATION_FROM_FILE", "perturbation_8h.html#a335364b39450e23bfefded6b7af8908ca436482abde005ab0919f5859360a4793", null ]
    ] ],
    [ "perturbation_copy", "perturbation_8h.html#afe0ed8debbd6552ef9fee1db9110f457", null ],
    [ "perturbation_create_from_file", "perturbation_8h.html#a4e57d63e5dfe3de8ead3805ebb1fcd19", null ],
    [ "perturbation_create_hyper_rectangle", "perturbation_8h.html#a9528c1856cb4f54dafeea19c694a105b", null ],
    [ "perturbation_delete", "perturbation_8h.html#a79de0b6483f6fd63b735e66d21a3069b", null ],
    [ "perturbation_get_epsilon_lowerbounds", "perturbation_8h.html#a89db5917e72b420301d5e20d8da9ebf2", null ],
    [ "perturbation_get_epsilon_upperbounds", "perturbation_8h.html#a3c30bf866d638a7c0552972e7da07a55", null ],
    [ "perturbation_get_file_stream", "perturbation_8h.html#aa5d5f36b2b13efe02d892ef675d0727c", null ],
    [ "perturbation_get_frame_height", "perturbation_8h.html#acd5db99ada65ab9f87982df41bb108a5", null ],
    [ "perturbation_get_frame_width", "perturbation_8h.html#ae050b188c442309b7f1058d161f4069a", null ],
    [ "perturbation_get_image_height", "perturbation_8h.html#a4d7d04dbe8f455fc983057e1a0c95c36", null ],
    [ "perturbation_get_image_width", "perturbation_8h.html#a97688d15be81ee292f6b6b9598ea682b", null ],
    [ "perturbation_get_magnitude", "perturbation_8h.html#ad953b11c5be07bd20f887657af4f58ad", null ],
    [ "perturbation_get_space_size", "perturbation_8h.html#a9bda3f21b94e8ea2fd49722d7ea42570", null ],
    [ "perturbation_get_type", "perturbation_8h.html#acc3cd2810fa6aa17373882c2838058b3", null ],
    [ "perturbation_print", "perturbation_8h.html#a4af7447ce885f95979a333c1eea4592c", null ],
    [ "perturbation_read", "perturbation_8h.html#aa32da99e4b1f03f8d564f3a91a5c7604", null ],
    [ "perturbation_set_magnitude", "perturbation_8h.html#a551c0538c1e2eb3834582e178045b73a", null ]
];