var structraf =
[
    [ "c", "structraf.html#ad6fb998ef9470dcb95719f1c95935031", null ],
    [ "delta", "structraf.html#af2679ccfbd4b68d4f1f651fdc2b3cc1c", null ],
    [ "index", "structraf.html#a89c9fde6d0763625df935f0418c65444", null ],
    [ "noise", "structraf.html#a7e4273a14d25d3fa4e28f5c27bd511b8", null ],
    [ "size", "structraf.html#ae4b42bd8cafc31d2ef251b85f4daed95", null ]
];