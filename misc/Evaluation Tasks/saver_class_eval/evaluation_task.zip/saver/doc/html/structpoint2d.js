var structpoint2d =
[
    [ "x", "structpoint2d.html#a553e62abf4e70361216cc6404169eda8", null ],
    [ "y", "structpoint2d.html#a62ced03d3bb8c2add8c0a35c97ec2469", null ]
];