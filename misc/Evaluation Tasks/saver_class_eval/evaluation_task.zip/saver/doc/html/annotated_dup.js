var annotated_dup =
[
    [ "abstract_classifier", "structabstract__classifier.html", "structabstract__classifier" ],
    [ "adversarial_region", "structadversarial__region.html", "structadversarial__region" ],
    [ "classifier", "structclassifier.html", "structclassifier" ],
    [ "counterexample", "structcounterexample.html", "structcounterexample" ],
    [ "counterexample_seeker", "structcounterexample__seeker.html", "structcounterexample__seeker" ],
    [ "dataset", "structdataset.html", "structdataset" ],
    [ "genetic_algorithm_status", "structgenetic__algorithm__status.html", "structgenetic__algorithm__status" ],
    [ "hybrid_classifier", "structhybrid__classifier.html", "structhybrid__classifier" ],
    [ "interval", "structinterval.html", "structinterval" ],
    [ "interval_classifier", "structinterval__classifier.html", "structinterval__classifier" ],
    [ "kernel", "structkernel.html", "structkernel" ],
    [ "options", "structoptions.html", "structoptions" ],
    [ "perturbation", "structperturbation.html", "structperturbation" ],
    [ "point2d", "structpoint2d.html", "structpoint2d" ],
    [ "raf", "structraf.html", "structraf" ],
    [ "raf_classifier", "structraf__classifier.html", "structraf__classifier" ],
    [ "stopwatch", "structstopwatch.html", "structstopwatch" ]
];