var kernel_8h =
[
    [ "Kernel", "kernel_8h.html#ac866e9923d7c5913017a67208a1bf8da", null ],
    [ "KernelType", "kernel_8h.html#a20fb43c4dec0741b9e11a076701f19e9", [
      [ "KERNEL_LINEAR", "kernel_8h.html#a20fb43c4dec0741b9e11a076701f19e9a0013f4c8698c727a0387d9bb43331e2c", null ],
      [ "KERNEL_RBF", "kernel_8h.html#a20fb43c4dec0741b9e11a076701f19e9aca9296ec7d7cd06b0395a5fe612aa7cb", null ],
      [ "KERNEL_POLYNOMIAL", "kernel_8h.html#a20fb43c4dec0741b9e11a076701f19e9ae2095b04c2c93d7a0b4359f10f7527d0", null ]
    ] ],
    [ "kernel_compute", "kernel_8h.html#aa889c42bf0e25cfe7eed1d8c7b63237d", null ],
    [ "kernel_create", "kernel_8h.html#ad0718e5f568ea4277631d0639fc3b77a", null ],
    [ "kernel_delete", "kernel_8h.html#a4d4fe2dd6f4147f8f05684df8af3ba0d", null ],
    [ "kernel_get_c", "kernel_8h.html#a42a6a5a0a5e77a442729617b89d0704e", null ],
    [ "kernel_get_degree", "kernel_8h.html#aa48df96ab78b79f72de51ce5118a65c8", null ],
    [ "kernel_get_gamma", "kernel_8h.html#a62a748f20705d55afdb3284183120f27", null ],
    [ "kernel_get_type", "kernel_8h.html#ad3a13d57e3fd7e06f7dd0ff766c95758", null ]
];