var structdataset =
[
    [ "data", "structdataset.html#a2156f8d0c04417f209f43827f89d6015", null ],
    [ "labels", "structdataset.html#a17fe22d2fac27783ca487740497ae5c0", null ],
    [ "size", "structdataset.html#ad329e7d991db8f41f104a366eea89f3f", null ],
    [ "space_size", "structdataset.html#aacf9924c0d4cbf22703daed5896f4987", null ]
];