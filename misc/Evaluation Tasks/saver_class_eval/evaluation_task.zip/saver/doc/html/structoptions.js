var structoptions =
[
    [ "counterexamples_file", "structoptions.html#a31e5bb7adc6e2c96495886c18cab6518", null ],
    [ "debug_output", "structoptions.html#a56174b499a001879c73add4f9f0f60f4", null ]
];