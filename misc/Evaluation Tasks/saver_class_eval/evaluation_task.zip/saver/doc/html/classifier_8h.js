var classifier_8h =
[
    [ "Classifier", "classifier_8h.html#a36389215a4be596be07adcf7eabd9a2a", null ],
    [ "ClassifierType", "classifier_8h.html#a22c2b5746818dea9a0669a09b3fb1be6", [
      [ "CLASSIFIER_BINARY", "classifier_8h.html#a22c2b5746818dea9a0669a09b3fb1be6adbab7ac938938de4f8346ba6d47e4988", null ],
      [ "CLASSIFIER_OVR", "classifier_8h.html#a22c2b5746818dea9a0669a09b3fb1be6a4808fb49414e2ef2d4b5b28ac804ba08", null ],
      [ "CLASSIFIER_OVO", "classifier_8h.html#a22c2b5746818dea9a0669a09b3fb1be6a9e39ce2934e4ce1230ac70f618e0d985", null ]
    ] ],
    [ "classifier_classify", "classifier_8h.html#abbca03a53c0b90657c82276d9838f516", null ],
    [ "classifier_create", "classifier_8h.html#ab4d8041dd00c341a901cee1d02a7fe46", null ],
    [ "classifier_delete", "classifier_8h.html#ae844038efae0911aab251a4a9aaaa818", null ],
    [ "classifier_get_alpha", "classifier_8h.html#a92e36950cce8dd9beb979bb02804fb33", null ],
    [ "classifier_get_bias", "classifier_8h.html#abf10a04e039d7178dc4783179659aa1e", null ],
    [ "classifier_get_classes", "classifier_8h.html#a3acb266e3ab069853e835f561b517feb", null ],
    [ "classifier_get_coefficients", "classifier_8h.html#a63200b0051b846642e9062e57c439c60", null ],
    [ "classifier_get_kernel", "classifier_8h.html#ac5717fbafb067c969aebd6b5ff9012c5", null ],
    [ "classifier_get_n_classes", "classifier_8h.html#a86e948ace7a4e17183b7485d31d354bc", null ],
    [ "classifier_get_n_support_vectors", "classifier_8h.html#a40381dd62eb15166180ce6939ae411cb", null ],
    [ "classifier_get_space_size", "classifier_8h.html#a599b4eafad6d9e63395cc950888ae11d", null ],
    [ "classifier_get_support_vectors", "classifier_8h.html#ab912d12bce094ad2bb8ebd5fce300bf8", null ],
    [ "classifier_get_type", "classifier_8h.html#a401aef9acec673cb0db6b4ba3e1a0d41", null ],
    [ "classifier_read", "classifier_8h.html#ab5d827cd28b9b2de919979a6822cd259", null ],
    [ "classifier_score", "classifier_8h.html#a2f476dce8f19e7c951cbb3ffb1719d4b", null ]
];