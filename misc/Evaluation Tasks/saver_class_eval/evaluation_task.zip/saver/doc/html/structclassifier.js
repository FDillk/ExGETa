var structclassifier =
[
    [ "alpha", "structclassifier.html#ae4e340fbdc9e70227f264e52a1ecec63", null ],
    [ "automatic_free", "structclassifier.html#a5d2150d1a488471531f0b0301cec083a", null ],
    [ "bias", "structclassifier.html#a290405cf7f4aa73c9ebf30de21ab9b13", null ],
    [ "buffer", "structclassifier.html#a3a62fada438b9a5c18e56580666edaa5", null ],
    [ "classes", "structclassifier.html#a5ca65644468b7c4d1d09d0b02687d8aa", null ],
    [ "coefficients", "structclassifier.html#a231673f32aceaf276642f06ff7468c07", null ],
    [ "kernel", "structclassifier.html#a98500ed270d46895178582284ae5da1e", null ],
    [ "n_classes", "structclassifier.html#a8006c1f000c2d5d13b466131e38ec9c2", null ],
    [ "n_support_vectors", "structclassifier.html#aeeb189301bca60d23f36eaed638017bc", null ],
    [ "space_size", "structclassifier.html#aa300f8981dc952371f538e5a3e092a11", null ],
    [ "support_vectors", "structclassifier.html#a963799a24fea436ee850268049802c00", null ],
    [ "type", "structclassifier.html#a68146e32122f4c8e19ec9ad6851ee4ee", null ]
];