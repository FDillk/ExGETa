var structinterval__classifier =
[
    [ "buffer", "structinterval__classifier.html#add85af0cf00060d8791946a91e4e9925", null ],
    [ "classifier", "structinterval__classifier.html#a3887cc3122fc60ca97e27d44649bcd74", null ]
];