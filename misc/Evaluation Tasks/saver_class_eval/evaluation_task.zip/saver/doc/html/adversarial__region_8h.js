var adversarial__region_8h =
[
    [ "adversarial_region", "structadversarial__region.html", "structadversarial__region" ],
    [ "AdversarialRegion", "adversarial__region_8h.html#aeed48d874392185971cd5d8d9b72d678", null ],
    [ "AdversarialRegionProperty", "adversarial__region_8h.html#a9b9b492893daf6ed6646d8551d52077b", null ],
    [ "adversarial_region_contains", "adversarial__region_8h.html#a669bb7ec4e5f409e4d716384d95d3599", null ],
    [ "adversarial_region_get_sample", "adversarial__region_8h.html#a6e4433729f8f3ee4cbf1ddda23fdfac4", null ],
    [ "adversarial_region_print", "adversarial__region_8h.html#a07bbf6e9bd772f3e91aa6e576b8879cc", null ]
];