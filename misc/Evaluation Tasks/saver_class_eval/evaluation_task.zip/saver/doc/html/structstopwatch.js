var structstopwatch =
[
    [ "start_time", "structstopwatch.html#a7a344c59b79cee7ab76a8d66713bfbc9", null ],
    [ "stop_time", "structstopwatch.html#a98db6c786c32091663c2495279e357d3", null ]
];