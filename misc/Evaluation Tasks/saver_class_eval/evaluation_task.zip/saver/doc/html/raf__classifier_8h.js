var raf__classifier_8h =
[
    [ "RafClassifier", "raf__classifier_8h.html#a7b35695c4c0126e97c062b1fc141578c", null ],
    [ "raf_classifier_classify", "raf__classifier_8h.html#af87f77b33b60316c973b9b523acce97e", null ],
    [ "raf_classifier_create", "raf__classifier_8h.html#ab865932bcb754fdaf2eb83e6540de85e", null ],
    [ "raf_classifier_delete", "raf__classifier_8h.html#acc042cc0bcd1a08a0a56ede14e8155a8", null ],
    [ "raf_classifier_score", "raf__classifier_8h.html#a68810bf9cd854337e0ba0e53a8bffbf7", null ]
];