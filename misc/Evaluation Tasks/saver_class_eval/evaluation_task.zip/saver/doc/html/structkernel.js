var structkernel =
[
    [ "c", "structkernel.html#af25e93846088dce2174b0b96748b913f", null ],
    [ "degree", "structkernel.html#af590d295ae525e63a9411104f83ca96f", null ],
    [ "gamma", "structkernel.html#a1e8bc3109fcd6cdd247e332091eac01a", null ],
    [ "type", "structkernel.html#a5021fa006d7a551bc913d8a5548ab32f", null ]
];