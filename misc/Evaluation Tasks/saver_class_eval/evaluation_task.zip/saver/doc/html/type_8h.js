var type_8h =
[
    [ "max", "type_8h.html#ac39d9cef6a5e030ba8d9e11121054268", null ],
    [ "min", "type_8h.html#abb702d8b501669a23aa0ab3b281b9384", null ],
    [ "round_down", "type_8h.html#aec51294914151e64536e79a46ec1e9c8", null ],
    [ "round_up", "type_8h.html#a3ee29932c4652551fba3131bdc706f95", null ],
    [ "Real", "type_8h.html#ab685845059e8a2c92743427d9a698c70", null ]
];