var counterexample_8h =
[
    [ "Counterexample", "counterexample_8h.html#a88452afaaac7ff39de7a18fb12647d2d", null ],
    [ "counterexample_create", "counterexample_8h.html#ae5f84e98afda3f663d747eadffe9de9f", null ],
    [ "counterexample_delete", "counterexample_8h.html#aeda5dc003ecc84e596f144715a3426d7", null ],
    [ "counterexample_get_nth_sample", "counterexample_8h.html#a21d9740d7507f74765837f8ea7815845", null ],
    [ "counterexample_get_samples_number", "counterexample_8h.html#a0d56236b6da47f21e4c51390dc65d1b6", null ],
    [ "counterexample_get_space_size", "counterexample_8h.html#a7b726156b4373e8f138ea08e33399081", null ],
    [ "counterexample_print", "counterexample_8h.html#acc3a1ed0f6eec13589a2168407ac96fb", null ]
];