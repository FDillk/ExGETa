var structabstract__classifier =
[
    [ "abstract_classifier", "structabstract__classifier.html#a9b2f16358055af263bd121198e9fe48e", null ],
    [ "abstract_domain", "structabstract__classifier.html#ab60084d70ac017c28c935c9decb1be2b", null ],
    [ "classifier", "structabstract__classifier.html#ab813522bc236bf252dd80382625b3a16", null ]
];