var structraf__classifier =
[
    [ "buffer", "structraf__classifier.html#a5e3c514d0143d8070ec0e006acf25fd9", null ],
    [ "classifier", "structraf__classifier.html#a9f9df899b8a35ffa5f85125bdb9b4ecf", null ]
];