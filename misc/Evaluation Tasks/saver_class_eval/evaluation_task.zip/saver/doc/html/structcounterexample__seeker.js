var structcounterexample__seeker =
[
    [ "abstract_classifier", "structcounterexample__seeker.html#a1139eb953e28b2344513f474640a077e", null ],
    [ "type", "structcounterexample__seeker.html#a5da6c55e895669c00206699f7736aca0", null ]
];