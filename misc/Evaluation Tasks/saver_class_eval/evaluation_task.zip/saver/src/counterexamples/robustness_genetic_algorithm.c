#include "robustness_genetic_algorithm.h"

#include <malloc.h>
#include <string.h>

#include "../type.h"
#include "../report_error.h"


unsigned int robustness_genetic_algorithm(
    Counterexample counterexample,
    const Classifier classifier,
    const AdversarialRegion adversarial_region
) {
    (void) counterexample;
    (void) classifier;
    (void) adversarial_region;


    return 0;
}
